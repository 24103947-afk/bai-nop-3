BỘ BÀI NỘP WEBSITE — THẾ GIỚI ĐỘNG VẬT

Bao_cao_du_an_website.docx:
- Mô tả dự án, công nghệ, tính năng, phần mô tả tiếng Anh và danh sách kiểm tra.
- Các mục W3C/WAVE và URL cần được cập nhật bằng kết quả thực tế trước khi nộp.

CSS_Grid_Flex_Huy_bai_nop.zip: mã nguồn website gồm HTML, CSS và ảnh.
