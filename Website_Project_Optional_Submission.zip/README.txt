OPTIONAL WEBSITE PROJECT SUBMISSION

Included:
- Project_Description_Animal_World.docx: English project description, four additional features, and evidence checklist.
- Bo_bai_nop_website_The_gioi_dong_vat.zip: website source bundle with HTML/CSS/images and the previous report.

Before submitting, publish the site, insert the real URL, and attach actual W3C/WAVE and responsive-layout screenshots.
